package lk.bytetechsolution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BytetechsolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BytetechsolutionApplication.class, args);
	}

}
